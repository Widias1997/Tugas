﻿Imports System.Console
Module Aplikasi_1
    Sub Main()
        OutputNama()
        LuasPersegiPanjang()
        KelilingPersegiPanjang()
        LuasSegitiga()
        KelilingSegitiga()
        LuasBalok()
        VolumeBalok()
        LuasLingkaran()
        LuasTabung()
        LuasTrapesium()
        CekGanjilGenap()
        CekPositifNegatif()

    End Sub

    Sub OutputNama()
        System.Console.WriteLine("Selamat Datang Di Aplikasi 1")

        'Pount A
        WriteLine()
        WriteLine()
        WriteLine("Point A")
        WriteLine("-------")

        'tampilnama
        WriteLine()
        WriteLine("===================")
        WriteLine("       Widias      ")
        WriteLine("    19081000011    ")
        WriteLine("        1D         ")
        WriteLine("D3 SISTEM INFORMASI")
        WriteLine("===================")
        WriteLine()

    End Sub

    Sub LuasPersegiPanjang()

        'Point B
        WriteLine("Point B")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Luas Persegi Panjang  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai P dan L
        '2. Hitung Luas = P * L
        '3. Tampilkan Hasil Luas

        Dim P, L, Luas As Integer

        '1. Masukkan Nilai P dan L
        Write("Masukkan Nilai Panjang   = ")
        P = ReadLine()
        Write("Masukkan Nilai Lebar     = ")
        L = ReadLine()

        '2. Hitung Luas Persegi Panjang
        Luas = P * L

        '3. Tampilkan Hasil Luas
        WriteLine("======================================")
        WriteLine(" Hasil Luas Persegei Panjang = " & Luas)
        WriteLine("======================================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub KelilingPersegiPanjang()

        'Point C
        WriteLine("Point C")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Keliling Persegi Panjang  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai P dan L
        '2. Hitung Keliling = 2 * (P + L) 
        '3. Tampilkan Hasil Keliling

        Dim P, L, keliling As Integer

        'Masukkan Nilai P dan L
        Write("Masukkan Nilai Panjang   = ")
        P = ReadLine()
        Write("Masukkan Nilai Lebar     = ")
        L = ReadLine()

        '2. Hitung Keliling = 2 * (P + L) 
        keliling = 2 * (P + L)

        '3. Tampilkan Hasil Keliling
        WriteLine("=============================================")
        WriteLine("Hasil Keliling Persegei Panjang = " & keliling)
        WriteLine("=============================================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub LuasSegitiga()

        'Point D
        WriteLine("Point D")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Luas Segitiga  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Alas dan Tinggi
        '2. Hitung Luas Segitiga = 1/2 * Alas * Tinggi
        '3. Tampilkan Hasil Luas

        Dim Alas, Tinggi, Luas As Integer

        '1. Masukkan Alas dan Tinggi
        Write("Masukkan Nilai Alas      = ")
        Alas = ReadLine()
        Write("Masukkan Nilai Tinggi    = ")
        Tinggi = ReadLine()

        '2. Hitung Luas Segitiga = 1/2 * Alas * Tinggi
        Luas = 1 * (Alas * Tinggi) / 2

        '3. Tampilkan Hasil Luas
        WriteLine("=============================")
        WriteLine("Hasil Luas Segitiga = " & Luas)
        WriteLine("=============================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub KelilingSegitiga()

        'Point E
        WriteLine("Point E")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Keliling Segitiga  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan sisi A, B, dan C
        '2. Hitung Keliling Segitiga = A + B + C
        '3. Tampilkan Hasil Keliling 

        Dim A, B, C, Keliling As Integer

        '1. Masukkan sisi A, B, dan C
        Write("Masukkan Sisi A = ")
        A = ReadLine()
        Write("Masukkan Sisi B = ")
        B = ReadLine()
        Write("Masukkan Sisi C = ")
        C = ReadLine()

        '2. Hitung Keliling Segitiga = A + B + C
        Keliling = A + B + C

        '3. Tampilkan Hasil Keliling
        WriteLine("=====================================")
        WriteLine("Hasil Keliling Segitiga = " & Keliling)
        WriteLine("=====================================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub LuasBalok()

        'Point F
        WriteLine("Point F")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Luas Balok  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma 
        '1. Masukkan Panjang, Lebar, Tinggi 
        '2. Hitung Luas Balok = 2 * (Panjang * Lebar + Panjang * Tinggi + Panjang * Lebar )
        '3. Tampilkan Luas Balok

        Dim Panjang, Lebar, Tinggi, Luas As Integer

        '1. Masukkan Panjang, Lebar, Tinggi 
        Write("Masukkan Nilai Panjang   = ")
        Panjang = ReadLine()
        Write("Masukkan Nilai Lebar     = ")
        Lebar = ReadLine()
        Write("Masukkan Nilai Tinggi    = ")
        Tinggi = ReadLine()

        '2. Hitung Luas Balok = 2 * (Panjang * Lebar + Panjang * Tinggi + Panjang * Lebar )
        Luas = 2 * (Panjang * Lebar + Panjang * Tinggi + Panjang * Lebar)

        '3. Tampilkan Luas Balok
        WriteLine("==========================")
        WriteLine("Hasil Luas Balok = " & Luas)
        WriteLine("==========================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub VolumeBalok()

        'Point G
        WriteLine("Point G")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Volume Balok  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        Dim Panjang, Lebar, Tinggi, Volume As Integer

        'algoritma 
        '1. Masukkan Panjang, Lebar, Tinggi
        '2. Hitung Volume Balok = Panjang * Lebar * Tinggi
        '3. Tampilkan Volume Balok 

        '1. Masukkan Panjang, Lebar, Tinggi
        Write("Masukkan Nilai Panjang   = ")
        Panjang = ReadLine()
        Write("Masukkan Nilai Lebar     = ")
        Lebar = ReadLine()
        Write("Masukkan Nilai Tinggi    = ")
        Tinggi = ReadLine()

        '2. Hitung Volume Balok = Panjang * Lebar * Tinggi
        Volume = Panjang * Lebar * Tinggi

        '3. Tampilkan Volume Balok 
        WriteLine("==============================")
        WriteLine("Hasil Volume Balok = " & Volume)
        WriteLine("==============================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub LuasLingkaran()

        'Point H
        WriteLine("Point H")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Luas Lingkaran  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan R / Jari-Jari
        '2. Hitung Luas Lingkaran = Pi * R ^ 2
        '3. Tampilkan Luas Lingkaran

        Dim R, Luas As Single
        Dim Pi = 22 / 7

        '1. Masukkan R / Jari-Jari
        Write("Masukkan Nilai Jari - Jari = ")
        R = ReadLine()

        '2. Hitung Luas Lingkaran = Pi * R ^ 2
        Luas = Pi * (R ^ 2)

        '3. Tampilkan Luas Lingkaran
        WriteLine("==============================")
        WriteLine("Hasil Luas Lingkaran = " & Luas)
        WriteLine("==============================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub LuasTabung()

        'Point I
        WriteLine("Point I")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Luas Tabung  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan R / Jari-Jari dan T / Tinggi Tabung
        '2. Hitung Luas Tabung = 2 * Pi * R * (R + T)
        '3. Tampilkan Luas Tabung

        Dim R, T, Luas As Single
        Dim Pi = 22 / 7

        '1. Masukkan R / Jari-Jari dan T / Tinggi Tabung
        Write("Masukkan Nilai Jari-Jari     = ")
        R = ReadLine()
        Write("Masukkan Nilai Tinggi        = ")
        T = ReadLine()

        '2. Hitung Luas Tabung = 2 * Pi * R * (R + T)
        Luas = 2 * Pi * R * (R + T)

        '3. Tampilkan Luas Tabung
        WriteLine("===========================")
        WriteLine("Hasil Luas Tabung = " & Luas)
        WriteLine("===========================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub LuasTrapesium()

        'Point J
        WriteLine("Point J")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Menghitung Luas Trapesium  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Sisi A, B dan Tinggi
        '2. Hitung Luas Trapesium = 1 * (A + B) * Tinggi / 2
        '3. Tampilkan Luas Trapesium

        Dim A, B, Tinggi, Luas As Single

        '1. Masukkan Sisi A, B dan Tinggi
        Write("Masukkan Sisi A      = ")
        A = ReadLine()
        Write("Masukkan Sisi B      = ")
        B = ReadLine()
        Write("Masukkan Sisi Timggi = ")
        Tinggi = ReadLine()

        '2. Hitung Luas Trapesium = 1/2 * (A + B) * Tinggi 
        Luas = 1 * (A + B) * Tinggi / 2

        '3. Tampilkan Luas Trapesium
        WriteLine("==============================")
        WriteLine("Hasil Luas Trapesium = " & Luas)
        WriteLine("==============================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub CekGanjilGenap()

        'Point K
        WriteLine("Point K")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Cek Bilangan Ganjil atau Genap  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'Algoritma
        '1. Masukkan Bilangan
        '2. Jika Bilangan Habis dibagi 2 adalah bilangan genap, jika tidak maka bilangan ganjil
        '3. Tampilkan Bilangan

        Dim Bilangan As Single
        Dim Hasil As String

        '1. Masukkan Bilangan
        Write("Masukkan Bilangan = ")
        Bilangan = ReadLine()

        '2. Jika Bilangan Habis dibagi 2 adalah bilangan genap, jika tidak maka bilangan ganjil
        If Bilangan Mod 2 = 0 Then
            Hasil = Bilangan & " Bilangan Genap "
        Else Hasil = Bilangan & " Bilangan Ganjil"
        End If

        '3. Tampilkan Bilangan
        WriteLine("=========================")
        WriteLine("Hasil Bilangan = " & Hasil)
        WriteLine("=========================")
        WriteLine("")
        WriteLine("")

    End Sub

    Sub CekPositifNegatif()

        'Point L
        WriteLine("Point L")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Cek Bilangan Postif atau Negatif  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Bilangan
        '2. Jika Bilangan > 0 = Bilangan Positif, Jika Bilangan < 0 = Bilangan Negatif
        '3. Tampilkan Bilangan

        Dim Bilangan As Single
        Dim Hasil As String

        '1. Masukkan Bilangan
        Write("Masukkan Bilangan = ")
        Bilangan = ReadLine()

        '2. Jika Bilangan > 0 = Bilangan Positif, Jika Bilangan < 0 = Bilangan Negatif
        If Bilangan >= 0 Then
            Hasil = Bilangan & " Bilangan Positif "
        Else Hasil = Bilangan & " Bilangan Negatif "
        End If

        '3. Tampilkan Bilangan
        WriteLine("=========================")
        WriteLine("Hasil Bilangan = " & Hasil)
        WriteLine("=========================")
        WriteLine("")
        WriteLine("")

    End Sub

End Module
