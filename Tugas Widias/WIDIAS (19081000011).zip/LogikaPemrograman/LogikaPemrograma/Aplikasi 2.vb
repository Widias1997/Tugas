﻿Imports System.Console
Module Aplikasi_2
    Sub Main()
        OutputNama()
        FahrenheitCelcius()
        FahrenheitReamur()
        ReamurFahrenheit()
        CelciusFahreheit()
        YardCm()
        FeetCm()
        JamMenit()

    End Sub

    Sub OutputNama()
        System.Console.WriteLine("Selamat Datang Di Aplikasi 2")

        'tampilnama
        WriteLine()
        WriteLine("========================")
        WriteLine("         WIDIAS         ")
        WriteLine("      19081000011       ")
        WriteLine("          1D            ")
        WriteLine("  D3 SISTEM INFORMASI   ")
        WriteLine("========================")
        WriteLine()

    End Sub

    Sub FahrenheitCelcius()

        'Point A
        WriteLine("Point A")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Konversi Suhu dari Fahrenheit ke Celcius  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Suhu Fahrenheit
        '2. Konversi Fahrenheit ke Celcius = 5 / 9 * (Nilai Suhu Fahrenheit - 32)
        '3. Tampilkan Konversi
        '_____________________

        'F = Fahrenheit
        'C = Celcius
        Dim F, C As Single

        '1. Masukkan Nilai Suhu Fahrenheit
        Write("Masukkan Nilai Suhu Fahrenheit = ")
        F = ReadLine()

        '2. Konversi Fahrenheit ke Celcius = 5 / 9 * (Nilai Suhu Fahrenheit - 32)
        C = 5 / 9 * (F - 32)

        '3. Tampilkan Konversi
        WriteLine("====================================================")
        WriteLine(" Konversi Fahrenheit ke Celcius = " & C & " Celcius ")
        WriteLine("====================================================")
        WriteLine()
        WriteLine()
        WriteLine()

    End Sub

    Sub FahrenheitReamur()

        'Point B
        WriteLine("Point B")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Konversi suhu dari Fahrenheit ke Reamur  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Suhu Fahrenheit
        '2. Konversi Fahrenheit ke Reamur = 4 / 9  * (Nilai Suhu Fahrenheit - 32)
        '3. Tampilkan Konversi
        '_____________________

        'F = Fahrenheit
        'R = Reamur
        Dim F, R As Single

        '1. Masukkan Nilai Suhu Fahrenheit
        Write("Masukkan Nilai Suhu Fahrenheit = ")
        F = ReadLine()

        '2. Konversi Fahrenheit ke Reamur = 4 / 9  * (Nilai Suhu Fahrenheit - 32)
        R = 4 / 9 * (F - 32)

        '3. Tampilkan Konversi
        WriteLine("==================================================")
        WriteLine(" Konversi Fahrenheit ke Reamur = " & R & " Reamur ")
        WriteLine("==================================================")
        WriteLine()
        WriteLine()
        WriteLine()

    End Sub

    Sub ReamurFahrenheit()

        'Point C
        WriteLine("Point C")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Konversi Suhu dari Reamur ke Fahrenheit   ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Suhu Reamur
        '2. Konversi Reamur ke Fahrenheit = 9 / 4 * (Nilai Suhu Reamur + 32)
        '3. Tampilkan Konversi
        '_____________________

        'R = Reamur
        'F = Fahrenheit
        Dim R, F As Single

        '1. Masukkan Nilai Suhu Fahrenheit
        Write("Masukkan Nilai Suhu Reamur = ")
        R = ReadLine()

        '2. Konversi Reamur ke Fahrenheit = 9 / 4 * (Nilai Suhu Reamur - 32)
        F = 9 / 4 * (R + 32)

        '3. Tampilkan Konversi
        WriteLine("======================================================")
        WriteLine(" Konversi Reamur ke Fahrenheit = " & F & " Fahrenheit ")
        WriteLine("======================================================")
        WriteLine()
        WriteLine()
        WriteLine()

    End Sub

    Sub CelciusFahreheit()

        'Point D
        WriteLine("Point D")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Konversi Suhu dari Celcius ke Fahrenheit  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Suhu Celcius
        '2. Konversi Celcius ke Fahrenheit = 9 / 5 * (Nilai Suhu Celcius + 32)
        '3. Tampilkan Konversi
        '_____________________    

        'C = Celsius
        'F= Fahrenheit
        Dim C, F As Single

        '1. Masukkan Nilai Suhu Celcius
        Write("Masukkan Nilai Suhu Celcius = ")
        C = ReadLine()

        '2. Konversi Celcius ke Fahrenheit = 9 / 5 * (Nilai Suhu Celcius + 32)
        F = 9 / 5 * (C + 32)

        '3. Tampilkan Konversi
        WriteLine("=======================================================")
        WriteLine(" Konversi Celcius ke Fahrenheit = " & F & " Fahrenheit ")
        WriteLine("=======================================================")
        WriteLine()
        WriteLine()
        WriteLine()

    End Sub

    Sub YardCm()

        'Point E
        WriteLine("Point E")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Konversi Bilangan dari Yard ke Cm ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Panjang Yard
        '2. Konversi Bilangan Yard ke Cm = Nilai Panjang * 91.44
        '3. Tampilkan Konversi
        '_____________________

        'P = Panjang
        Dim P, Cm As Single

        '1. Masukkan Nilai Panjang Yard
        Write("Masukkan Nilai Panjang Yard = ")
        P = ReadLine()

        '2. Konversi Bilangan Yard ke Cm = Nilai Panjang * 91.44
        Cm = P * 91.44

        '3. Tampilkan Konversi
        WriteLine("=====================================")
        WriteLine(" Konversi Yard ke Cm = " & Cm & " Cm ")
        WriteLine("=====================================")
        WriteLine()
        WriteLine()
        WriteLine()

    End Sub

    Sub FeetCm()

        'Point F
        WriteLine("Point F")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Konversi Bilangan dari Yard ke Cm  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Panjang Feet
        '2. Konversi Bilangan Feet ke Cm = Nilai Panjang * 30.48
        '3. Tampilkan Konversi
        '_____________________

        'P = Panjang
        Dim P, Cm As Single

        '1. Masukkan Nilai Panjang Feet
        Write("Masukkan Nilai Panjang Feet = ")
        P = ReadLine()

        '2. Konversi Bilangan Feet ke Cm = Nilai Panjang * 30.48
        Cm = P * 30.48

        '3. Tampilkan Konversi
        WriteLine("=====================================")
        WriteLine(" Konversi Feet ke Cm = " & Cm & " Cm ")
        WriteLine("=====================================")
        WriteLine()
        WriteLine()
        WriteLine()

    End Sub

    Sub JamMenit()

        'Point G
        WriteLine("Point G")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine("  Konversi Waktu dari Jam ke Menit  ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Jumlah Waktu dari Jam 
        '2. Konversi Jumlah Waktu dari Jam ke Menit = Jumlah Waktu dari Jam  * 60
        '3. Tampilkan Konversi
        '_____________________

        Dim Jam, Menit As Single

        '1. Masukkan Jumlah Waktu dari Jam 
        Write("Masukkan Jumlah Waktu Jam = ")
        Jam = ReadLine()

        '2. Konversi Jumlah Waktu dari Jam ke Menit = Jumlah Waktu dari Jam  * 60
        Menit = Jam * 60

        '3. Tampilkan Konversi
        WriteLine("=======================================================")
        WriteLine(" Konversi Waktu dari Jam ke Menit = " & Menit & " Menit")
        WriteLine("=======================================================")
        WriteLine()
        WriteLine()


    End Sub

End Module
