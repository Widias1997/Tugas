﻿Imports System.Console
Module Aplikasi_3
    Sub Main()
        OutputNama()
        LuasKelilingPersegiPanjang()
        LuasKelilingPersegi()
        LuasKelilingSegitiga()
        LuasVolumeBalok()
        Fahrenheitt_CelciusReamur()
        Jam_MenitDetik()

    End Sub

    Sub OutputNama()
        System.Console.WriteLine("Selamat Datang Di Aplikasi 3")

        'tampilnama
        WriteLine()
        WriteLine("=========================")
        WriteLine("         WIDIAS          ")
        WriteLine("       19081000011       ")
        WriteLine("           1D            ")
        WriteLine("   D3 SISTEM INFORMASI   ")
        WriteLine("=========================")
        WriteLine()

    End Sub

    Sub LuasKelilingPersegiPanjang()

        'Point A
        WriteLine("Point A")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine(" Luas Dan Keliling Persegi Panjang ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai P dan L
        '2. Hitung Luas = P * L
        '3. Hitung Keliling = 2 * (P + L) 
        '4. Tampilkan Hasil Luas
        '5. Tampilkan Hasil Keliling

        Dim P, L, Luas, Keliling As Integer

        '1. Masukkan Nilai P dan L
        Write("Masukkan Nilai Panjang    = ")
        P = ReadLine()
        Write("Masukkan Nilai Lebar      = ")
        L = ReadLine()

        '2. Hitung Luas = P * L
        Luas = P * L

        '3. Hitung Keliling = 2 * (P + L) 
        Keliling = 2 * (P + L)

        '4. Tampilkan Hasil Luas
        WriteLine()
        WriteLine("=====================================")
        WriteLine("Hasil Luas Persegei Panjang = " & Luas)
        WriteLine("=====================================")

        '5. Tampilkan Hasil Keliling
        WriteLine("=============================================")
        WriteLine("Hasil Keliling Persegei Panjang = " & Keliling)
        WriteLine("=============================================")
        WriteLine()
        WriteLine()

    End Sub

    Sub LuasKelilingPersegi()

        'Point B
        WriteLine("Point B")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine(" Luas Dan Keliling Persegi ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Sisi
        '2. Hitung Luas = Sisi * Sisi
        '3. Hitung Keliling = 4 * Sisi 
        '4. Tampilkan Hasil Luas
        '5. Tampilkan Hasil Keliling

        Dim S, Luas, Keliling As Integer

        '1. Masukkan Nilai Sisi
        Write("Masukkan Nilai Sisi = ")
        S = ReadLine()

        '2. Hitung Luas = Sisi * Sisi
        Luas = S * S

        '3. Hitung Keliling = 4 * Sisi
        Keliling = 4 * S

        '4. Tampilkan Hasil Luas
        WriteLine()
        WriteLine("=============================")
        WriteLine("Hasil Luas Persegei = " & Luas)
        WriteLine("=============================")

        '5. Tampilkan Hasil Keliling
        WriteLine("=====================================")
        WriteLine("Hasil Keliling Persegei = " & Keliling)
        WriteLine("=====================================")
        WriteLine()
        WriteLine()


    End Sub

    Sub LuasKelilingSegitiga()

        'Point C
        WriteLine("Point C")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine(" Luas Dan Keliling Segitiga ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Alas dan Tinggi, Sisi A, B, dan C
        '2. Hitung Luas Segitiga = 1/2 * Alas * Tinggi
        '3. Hitung Keliling Segitiga = A + B + C
        '4. Tampilkan Hasil Luas
        '5. Tampilkan Hasil Keliling

        'A, B, C = Sisi Segitiga 
        Dim Alas, Tinggi, A, B, C, Luas, Keliling As Integer

        '1. Masukkan Nilai Alas dan Tinggi, Sisi A, B, dan C
        Write("Masukkan Nilai Alas      = ")
        Alas = ReadLine()
        Write("Masukkan Nilai Tinggi    = ")
        Tinggi = ReadLine()

        WriteLine("-------------------------------")

        Write("Masukkan Sisi A          = ")
        A = ReadLine()
        Write("Masukkan Sisi B          = ")
        B = ReadLine()
        Write("Masukkan Sisi C          = ")
        C = ReadLine()

        '2. Hitung Luas Segitiga = 1/2 * Alas * Tinggi
        Luas = 1 * Alas * Tinggi / 2

        '3. Hitung Keliling Segitiga = A + B + C
        Keliling = A + B + C

        '4. Tampilkan Hasil Luas
        WriteLine()
        WriteLine("=============================")
        WriteLine("Hasil Luas Segitiga = " & Luas)
        WriteLine("=============================")

        '5. Tampilkan Hasil Keliling
        WriteLine("=====================================")
        WriteLine("Hasil Keliling Segitiga = " & Keliling)
        WriteLine("=====================================")
        WriteLine()
        WriteLine()

    End Sub

    Sub LuasVolumeBalok()

        'Point D
        WriteLine("Point D")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine(" Luas Dan Volume Balok ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma 
        '1. Masukkan Panjang, Lebar, Tinggi 
        '2. Hitung Luas Balok = 2 * (Panjang * Lebar + Panjang * Tinggi + Panjang * Lebar )
        '3. Hitung Volume Balok = Panjang * Lebar * Tinggi
        '4. Tampilkan Luas Balok
        '5. Tampilkan Volume Balok 

        'P = Panjang
        'L = Lebar
        'T = Tinggi
        Dim P, L, T, Luas, Volume As Integer

        '1. Masukkan Panjang, Lebar, Tinggi 
        Write("Masukkan Nilai Panjang   = ")
        P = ReadLine()
        Write("Masukkan Nilai Lebar     = ")
        L = ReadLine()
        Write("Masukkan Nilai Tinggi    = ")
        T = ReadLine()

        '2. Hitung Luas Balok = 2 * (Panjang * Lebar + Panjang * Tinggi + Panjang * Lebar )
        Luas = 2 * (P * L + P * T + P * L)

        '3. Hitung Volume Balok = Panjang * Lebar * Tinggi
        Volume = P * L * T

        '4. Tampilkan Luas Balok
        WriteLine()
        WriteLine("==========================")
        WriteLine("Hasil Luas Balok = " & Luas)
        WriteLine("==========================")

        '5. Tampilkan Volume Balok 
        WriteLine("==============================")
        WriteLine("Hasil Volume Balok = " & Volume)
        WriteLine("==============================")
        WriteLine()
        WriteLine()


    End Sub

    Sub Fahrenheitt_CelciusReamur()

        'Point E
        WriteLine("Point E")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine(" Konversi Suhu dari Fahrenheit ke Celcius dan Reamur ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Nilai Suhu Fahrenheit
        '2. Konversi Fahrenheit ke Celcius = 5 / 9 * (Nilai Suhu Fahrenheit - 32)
        '3. Konversi Fahrenheit ke Reamur = 4 / 9  * (Nilai Suhu Fahrenheit - 32)
        '4. Tampilkan Konversi Fahrenheit ke Celcius
        '5. Tampilkan Konversi Fahrenheit ke Reamur

        'F = Fahrenheit
        'C = Celcius
        'R = Reamur
        Dim F, C, R As Single

        '1. Masukkan Nilai Suhu Fahrenheit
        Write("Masukkan Nilai Suhu Fahrenheit = ")
        F = ReadLine()

        '2. Konversi Fahrenheit ke Celcius = 5 / 9 * (Nilai Suhu Fahrenheit - 32)
        C = 5 / 9 * (F - 32)

        '3. Konversi Fahrenheit ke Reamur = 4 / 9  * (Nilai Suhu Fahrenheit - 32)
        R = 4 / 9 * (F - 32)

        '4. Tampilkan Konversi Fahrenheit ke Celcius
        WriteLine()
        WriteLine("===================================================")
        WriteLine("Konversi Fahrenheit ke Celcius = " & C & " Celcius ")
        WriteLine("===================================================")

        '5. Tampilkan Konversi Fahrenheit ke Reamur
        WriteLine("=================================================")
        WriteLine("Konversi Fahrenheit ke Reamur = " & R & " Reamur ")
        WriteLine("=================================================")
        WriteLine()
        WriteLine()

    End Sub

    Sub Jam_MenitDetik()

        'Point F
        WriteLine("Point F")
        WriteLine("-------")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine(" Konversi Waktu dari Jam ke Menit dan Detik ")
        WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        WriteLine()

        'algoritma
        '1. Masukkan Jumlah Waktu dari Jam 
        '2. Konversi Jumlah Waktu dari Jam ke Menit = Jumlah Waktu dari Jam  * 60
        '3. Konversi Jumlah Waktu dari Jam ke Detik = Jumlah Waktu dari Jam  * 3600
        '4. Tampilkan Konversi Waktu dari Jam ke Menit
        '5. Tampilkan Konversi Waktu dari Jam ke Detik

        Dim Jam, Menit, Detik As Single

        '1. Masukkan Jumlah Waktu dari Jam 
        Write("Masukkan Jumlah Waktu Jam = ")
        Jam = ReadLine()

        '2. Konversi Jumlah Waktu dari Jam ke Menit = Jumlah Waktu dari Jam  * 60
        Menit = Jam * 60

        '3. Konversi Jumlah Waktu dari Jam ke Detik = Jumlah Waktu dari Jam  * 3600
        Detik = Jam * 3600

        '4. Tampilkan Konversi Waktu dari Jam ke Menit
        WriteLine()
        WriteLine("======================================================")
        WriteLine("Konversi Waktu dari Jam ke Menit = " & Menit & " Menit")
        WriteLine("======================================================")

        '5. Tampilkan Konversi Waktu dari Jam ke Detik
        WriteLine("======================================================")
        WriteLine("Konversi Waktu dari Jam ke Detik = " & Detik & " Detik")
        WriteLine("======================================================")
        WriteLine()
        WriteLine()

    End Sub
End Module
