﻿Module Modulelogika

    Dim nilai As Integer

    Private Property ReadLine As Byte

    Sub Main()
        aplikasi5a()
    End Sub

    Sub cekkelulusanLOGIKA()
        'LULUS Jika:
        'nilaiuas > 90 OR nilaiuts > 70 AND nilaitugas > 80

    End Sub

    Sub aplikasi5a()
        '1. Siapkan variabel: Status, Nilai
        Dim status As String
        Dim nilai As Byte

        '2. Input Nilai
        WriteLine(" Masukkan Nilai = ")
        nilai = ReadLine()
        '3. Cek Nilai ( Jika Nilaiuas > 90 OR nilaiuts > 70 AND nilaitugas > 80, maka lulus )
        If nilai("Nilaiuas > 90 Or nilaiuts > 70 And nilaitugas > 80") Then
            status = "LULUS"
        Else
            status = "TIDAK LULUS"
        End If
        '4. Output status
        WriteLine("STATUS ANDA = " & status)
        WriteLine()

    End Sub

End Module
